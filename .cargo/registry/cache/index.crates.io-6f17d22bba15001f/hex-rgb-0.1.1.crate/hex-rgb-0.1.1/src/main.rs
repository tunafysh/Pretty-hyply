mod cli;

fn main() {
    cli::init();
}
