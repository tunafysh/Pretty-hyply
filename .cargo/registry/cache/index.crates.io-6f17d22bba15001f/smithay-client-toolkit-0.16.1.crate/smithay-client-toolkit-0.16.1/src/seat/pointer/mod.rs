//! Utilities to work with pointers and their icons

mod theme;

pub use self::theme::{ThemeManager, ThemeSpec, ThemedPointer};
