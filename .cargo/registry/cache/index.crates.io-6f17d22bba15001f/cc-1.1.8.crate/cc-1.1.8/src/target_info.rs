//! This file is generated code. Please edit the generator
//! in dev-tools/gen-target-info if you need to make changes.

pub const RISCV_ARCH_MAPPING: &[(&str, &str)] = &[
    ("riscv32gc", "riscv32"),
    ("riscv32i", "riscv32"),
    ("riscv32im", "riscv32"),
    ("riscv32ima", "riscv32"),
    ("riscv32imac", "riscv32"),
    ("riscv32imafc", "riscv32"),
    ("riscv32imc", "riscv32"),
    ("riscv64gc", "riscv64"),
    ("riscv64imac", "riscv64"),
];
