See the documentation for [`Command::multicall`][crate::Command::multicall] for rationale.

This example omits the implementation of displaying address config

```console
$ hostname
www

```
*Note: without the links setup, we can't demonstrate the multicall behavior*
